package com.flex.client;

import net.fabricmc.api.ModInitializer;

public class FlexClient implements ModInitializer {
    @Override
    public void onInitialize() {
        // This mod is purely client-side (rendering / GUI), nothing needed here.
    }
}
