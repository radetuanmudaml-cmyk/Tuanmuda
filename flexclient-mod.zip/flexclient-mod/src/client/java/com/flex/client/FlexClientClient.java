package com.flex.client;

import com.flex.client.gui.ClickGuiScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import org.lwjgl.glfw.GLFW;

public class FlexClientClient implements ClientModInitializer {

    public static ModConfig CONFIG;
    public static KeyBinding menuKey;

    // used for the "hit color" flash effect
    private static long lastHitTimeMs = -1L;
    private static final long HIT_FLASH_DURATION_MS = 250L;

    @Override
    public void onInitializeClient() {
        CONFIG = ModConfig.load();

        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.flexclient.menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_F8,
                "key.categories.flexclient"
        ));

        // Open the GUI when F8 is pressed
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new ClickGuiScreen());
                }
            }
        });

        // Flash a colored overlay right after we land a hit ("hit color")
        AttackEntityCallback.EVENT.register((PlayerEntity player, net.minecraft.world.World world, Hand hand, Entity entity, EntityHitResult hitResult) -> {
            if (CONFIG.hitColorEnabled) {
                lastHitTimeMs = System.currentTimeMillis();
            }
            return ActionResult.PASS;
        });

        // HUD drawing: FPS counter, custom crosshair, hit flash, sky tint overlay
        HudRenderCallback.EVENT.register(this::onHudRender);

        // World drawing: custom colored hitboxes ("hitbox color")
        WorldRenderEvents.AFTER_ENTITIES.register(this::onRenderHitboxes);
    }

    private void onHudRender(DrawContext ctx, net.minecraft.client.render.RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        int screenW = ctx.getScaledWindowWidth();
        int screenH = ctx.getScaledWindowHeight();

        // --- Sky color overlay (approximation: tints the top band of the screen) ---
        if (CONFIG.skyColorEnabled) {
            int alpha = (int) (CONFIG.skyColorAlpha * 255) << 24;
            int color = alpha | (CONFIG.skyColor & 0xFFFFFF);
            ctx.fill(0, 0, screenW, screenH / 3, color);
        }

        // --- FPS display ---
        if (CONFIG.fpsDisplayEnabled) {
            int fps = mc.getCurrentFps();
            ctx.drawTextWithShadow(mc.textRenderer, Text.literal("FPS: " + fps), 6, 6, 0xFFFFFF);
        }

        // --- Custom crosshair ---
        if (CONFIG.customCrosshairEnabled) {
            int cx = screenW / 2;
            int cy = screenH / 2;
            int color = 0xFF000000 | (CONFIG.crosshairColor & 0xFFFFFF);
            switch (CONFIG.crosshairStyle) {
                case DOT -> ctx.fill(cx - 1, cy - 1, cx + 1, cy + 1, color);
                case CIRCLE -> {
                    // cheap "circle" made of 4 ticks
                    ctx.fill(cx - 4, cy, cx - 2, cy + 1, color);
                    ctx.fill(cx + 2, cy, cx + 4, cy + 1, color);
                    ctx.fill(cx, cy - 4, cx + 1, cy - 2, color);
                    ctx.fill(cx, cy + 2, cx + 1, cy + 4, color);
                }
                case CROSS -> {
                    ctx.fill(cx - 5, cy, cx + 5, cy + 1, color);
                    ctx.fill(cx, cy - 5, cx + 1, cy + 5, color);
                }
            }
        }

        // --- Hit color flash ---
        if (CONFIG.hitColorEnabled && lastHitTimeMs > 0) {
            long elapsed = System.currentTimeMillis() - lastHitTimeMs;
            if (elapsed < HIT_FLASH_DURATION_MS) {
                float t = 1.0f - (elapsed / (float) HIT_FLASH_DURATION_MS);
                int alpha = (int) (t * 90) << 24;
                int color = alpha | (CONFIG.hitColor & 0xFFFFFF);
                ctx.fill(0, 0, screenW, screenH, color);
            }
        }
    }

    private void onRenderHitboxes(WorldRenderContext context) {
        if (!CONFIG.hitboxColorEnabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;

        VertexConsumerProvider consumers = context.consumers();
        if (consumers == null) return;
        VertexConsumer vc = consumers.getBuffer(RenderLayer.getLines());

        float r = ((CONFIG.hitboxColor >> 16) & 0xFF) / 255f;
        float g = ((CONFIG.hitboxColor >> 8) & 0xFF) / 255f;
        float b = (CONFIG.hitboxColor & 0xFF) / 255f;

        double camX = context.camera().getPos().x;
        double camY = context.camera().getPos().y;
        double camZ = context.camera().getPos().z;

        for (Entity entity : mc.world.getEntities()) {
            if (!(entity instanceof LivingEntity) || entity == mc.player) continue;
            if (entity.squaredDistanceTo(mc.player) > 64 * 64) continue;

            Box box = entity.getBoundingBox().offset(-camX, -camY, -camZ);
            // NOTE: WorldRenderer.drawBox is a vanilla utility for drawing a wireframe box.
            // If your mappings name it differently, check "WorldRenderer" in your IDE (Ctrl+click)
            // for the equivalent static method and adjust this call.
            WorldRenderer.drawBox(context.matrixStack(), vc, box, r, g, b, 1.0f);
        }
    }
}
