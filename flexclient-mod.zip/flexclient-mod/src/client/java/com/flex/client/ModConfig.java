package com.flex.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Holds every toggle/color shown in the F8 menu.
 * Colors are stored as 0xRRGGBB ints.
 */
public class ModConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("flexclient.json");

    // ---- PVP tab ----
    public boolean hitColorEnabled = true;
    public int hitColor = 0xFF3B3B;

    public boolean skyColorEnabled = false;
    public int skyColor = 0x87CEEB;
    public float skyColorAlpha = 0.15f;

    public boolean hitboxColorEnabled = false;
    public int hitboxColor = 0xFF0000;

    public boolean fpsDisplayEnabled = true;

    // ---- Crosshair tab ----
    public boolean customCrosshairEnabled = false;
    public int crosshairColor = 0xFFFFFF;
    public CrosshairStyle crosshairStyle = CrosshairStyle.CROSS;

    // ---- Fullbright tab ----
    public boolean fullbrightEnabled = false;

    public enum CrosshairStyle {
        CROSS, DOT, CIRCLE
    }

    public static ModConfig load() {
        if (Files.exists(FILE)) {
            try (Reader reader = Files.newBufferedReader(FILE, StandardCharsets.UTF_8)) {
                ModConfig cfg = GSON.fromJson(reader, ModConfig.class);
                if (cfg != null) return cfg;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return new ModConfig();
    }

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            try (Writer writer = Files.newBufferedWriter(FILE, StandardCharsets.UTF_8)) {
                GSON.toJson(this, writer);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
