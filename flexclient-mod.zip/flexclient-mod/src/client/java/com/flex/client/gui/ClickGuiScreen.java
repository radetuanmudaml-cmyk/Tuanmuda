package com.flex.client.gui;

import com.flex.client.FlexClientClient;
import com.flex.client.ModConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/**
 * Simple tabbed "/settings"-style click GUI.
 * Tabs: PVP, Crosshair, Fullbright.
 * (Macro tab intentionally not implemented - see chat explanation.)
 */
public class ClickGuiScreen extends Screen {

    private enum Tab { PVP, CROSSHAIR, FULLBRIGHT }

    private Tab currentTab = Tab.PVP;
    private final ModConfig cfg = FlexClientClient.CONFIG;

    public ClickGuiScreen() {
        super(Text.literal("FlexClient"));
    }

    @Override
    protected void init() {
        super.init();
        int panelX = this.width / 2 - 110;
        int tabY = this.height / 2 - 100;

        // Tab buttons
        addDrawableChild(ButtonWidget.builder(Text.literal("PVP"), b -> { currentTab = Tab.PVP; rebuild(); })
                .dimensions(panelX, tabY, 70, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Crosshair"), b -> { currentTab = Tab.CROSSHAIR; rebuild(); })
                .dimensions(panelX + 75, tabY, 70, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Fullbright"), b -> { currentTab = Tab.FULLBRIGHT; rebuild(); })
                .dimensions(panelX + 150, tabY, 70, 20).build());

        int optionY = tabY + 28;

        switch (currentTab) {
            case PVP -> {
                addToggle(panelX, optionY, "Hit Color", cfg.hitColorEnabled, v -> cfg.hitColorEnabled = v);
                addToggle(panelX, optionY += 24, "Sky Color", cfg.skyColorEnabled, v -> cfg.skyColorEnabled = v);
                addToggle(panelX, optionY += 24, "Hitbox Color", cfg.hitboxColorEnabled, v -> cfg.hitboxColorEnabled = v);
                addToggle(panelX, optionY += 24, "FPS Display", cfg.fpsDisplayEnabled, v -> cfg.fpsDisplayEnabled = v);
            }
            case CROSSHAIR -> {
                addToggle(panelX, optionY, "Custom Crosshair", cfg.customCrosshairEnabled, v -> cfg.customCrosshairEnabled = v);
                addDrawableChild(ButtonWidget.builder(Text.literal("Style: " + cfg.crosshairStyle), b -> {
                    ModConfig.CrosshairStyle[] styles = ModConfig.CrosshairStyle.values();
                    int next = (cfg.crosshairStyle.ordinal() + 1) % styles.length;
                    cfg.crosshairStyle = styles[next];
                    rebuild();
                }).dimensions(panelX, optionY += 24, 220, 20).build());
            }
            case FULLBRIGHT -> {
                addToggle(panelX, optionY, "Fullbright", cfg.fullbrightEnabled, v -> cfg.fullbrightEnabled = v);
            }
        }

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> this.close())
                .dimensions(panelX, tabY + 220, 220, 20).build());
    }

    private void addToggle(int x, int y, String label, boolean current, java.util.function.Consumer<Boolean> setter) {
        addDrawableChild(ButtonWidget.builder(Text.literal(label + ": " + (current ? "ON" : "OFF")), b -> {
            boolean newVal = !current;
            setter.accept(newVal);
            rebuild();
        }).dimensions(x, y, 220, 20).build());
    }

    private void rebuild() {
        this.clearChildren();
        this.init();
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        this.renderBackground(ctx, mouseX, mouseY, delta);
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, "FlexClient - F8 to close",
                this.width / 2, this.height / 2 - 120, 0xFFFFFF);
    }

    @Override
    public boolean shouldPauseGame() {
        return false;
    }

    @Override
    public void close() {
        cfg.save();
        super.close();
    }
}
