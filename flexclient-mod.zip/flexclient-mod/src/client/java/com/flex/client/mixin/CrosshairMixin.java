package com.flex.client.mixin;

import com.flex.client.FlexClientClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Cancels the vanilla crosshair draw when our custom crosshair is turned on,
 * so the two don't overlap.
 *
 * NOTE ON MAPPINGS: "renderCrosshair" is the Yarn name for this method as of
 * 1.21.x. If it fails to compile, open InGameHud in your IDE and confirm the
 * method name (it renders the small "+" in the middle of the screen).
 */
@Mixin(InGameHud.class)
public class CrosshairMixin {

    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void flexclient$hideVanillaCrosshair(DrawContext context, net.minecraft.client.render.RenderTickCounter tickCounter, CallbackInfo ci) {
        if (FlexClientClient.CONFIG != null && FlexClientClient.CONFIG.customCrosshairEnabled) {
            ci.cancel();
        }
    }
}
