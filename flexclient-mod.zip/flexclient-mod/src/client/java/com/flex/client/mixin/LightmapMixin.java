package com.flex.client.mixin;

import com.flex.client.FlexClientClient;
import net.minecraft.client.render.LightmapTextureManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Fullbright implementation.
 *
 * NOTE ON MAPPINGS: "update" is the Yarn name (as of 1.21.4) for the method that
 * recalculates the lightmap texture each frame. If this fails to compile, open
 * LightmapTextureManager in your IDE (Ctrl+Click from an import) and confirm the
 * method name/signature still matches - Yarn mappings occasionally get renamed
 * between versions.
 */
@Mixin(LightmapTextureManager.class)
public class LightmapMixin {

    @Inject(method = "update", at = @At("RETURN"))
    private void flexclient$fullbright(float tickDelta, CallbackInfo ci) {
        if (FlexClientClient.CONFIG != null && FlexClientClient.CONFIG.fullbrightEnabled) {
            LightmapTextureManager self = (LightmapTextureManager) (Object) this;
            self.getTexture().getImage().fillRect(0, 0, 16, 16, 0xFFFFFFFF);
            self.getTexture().upload();
        }
    }
}
