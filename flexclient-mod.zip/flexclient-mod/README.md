# FlexClient (starter project)

Mod Fabric untuk Minecraft **1.21.4** (Fabric Loader 0.19.3). Buka menu dengan **F8**.

## Cara pakai
1. Extract folder ini.
2. Buka di IntelliJ IDEA (File > Open > pilih folder `flexclient-mod`).
3. Tunggu Gradle sync selesai (butuh internet, akan download Minecraft + mappings + Fabric API).
4. Jalankan run config **Minecraft Client** (Gradle akan generate otomatis lewat Fabric Loom, atau jalankan `./gradlew runClient`).
5. In-game, tekan **F8** untuk buka menu.

## Yang sudah ada
- **F8** membuka GUI dengan 3 tab: **PVP**, **Crosshair**, **Fullbright**
- PVP: Hit Color (flash warna saat mukul), Sky Color (overlay tint), Hitbox Color (kotak warna di sekitar entity), FPS Display
- Crosshair: custom crosshair (cross / dot / circle), sekaligus nyembunyiin crosshair vanilla
- Fullbright: paksa lightmap ke terang penuh
- Config otomatis tersimpan di `config/flexclient.json`

## Yang SENGAJA tidak dibuat: kategori Macro
Auto hit crystal, auto safe anchor, aim assist, dan auto totem itu automation/cheat yang:
- Kebanyakan server modern pakai anticheat (Grim, Vulcan, dll) yang mendeteksi pola ini dan langsung ban
- Ngasih keunggulan curang dibanding pemain lain secara langsung

Kalau kamu latihan combat manual, saya bisa bantu bikin QoL yang legal (misalnya auto-sprint reset, item switcher, dsb) — tinggal bilang.

## Catatan teknis (kalau ada error compile)
Dua mixin (`LightmapMixin`, `CrosshairMixin`) menargetkan method internal Minecraft yang nama mapping-nya bisa berubah antar versi. Kalau gagal compile:
- Buka class terkait (`LightmapTextureManager` / `InGameHud`) lewat Ctrl+Click di IDE
- Cek nama method yang cocok (biasanya masih mirip: yang update lightmap / yang render crosshair)
- Sesuaikan nama method di mixin

Warna di GUI sekarang pakai preset/cycle sederhana biar cepat jalan — kalau mau color picker RGB penuh (slider R/G/B atau input hex), tinggal bilang, nanti saya tambahin ke `ClickGuiScreen`.
